"""Default plugin settings."""

PLUGIN_NAME = "AI GIS Agent"
FRONTEND_DIST_DIR = "resources/frontend_dist"
CONFIG_VERSION = 2

DEFAULT_CONFIG = {
    "config_version": CONFIG_VERSION,
    "llm": {
        "provider": "openai_compatible",
        "model": "",
        "base_url": "",
        "api_key": "",
        "temperature": 0.1,
        "max_tokens": 16384,
        "max_context_tokens": 32768,
        "request_timeout_seconds": 300,
    },
    "database": {
        "path": "~/.qgis_hermes_agent/state.db",
        "max_sessions": 1000,
    },
    "executor": {
        "execution_mode": "current_qgis",
        "timeout_seconds": 300,
        "max_memory_mb": 2048,
        "workspace_dir": "~/.qgis_hermes_agent/workspaces",
    },
    "skills": {
        "custom_skills_dir": "~/.qgis_hermes_agent/custom_skills",
        "custom_tools_dir": "~/.qgis_hermes_agent/custom_tools",
    },
    "ui": {
        "panel_width": 420,
        "theme": "auto",
        "language": "zh-CN",
    },
}
