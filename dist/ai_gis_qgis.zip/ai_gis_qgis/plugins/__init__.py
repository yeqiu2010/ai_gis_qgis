"""Bundled trusted Plugins."""
