"""Bundled trusted Plugins."""
