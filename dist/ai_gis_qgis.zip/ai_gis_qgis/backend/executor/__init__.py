"""QGIS execution package."""
