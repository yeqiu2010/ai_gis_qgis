"""Minimal tool registry."""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any

ToolHandler = Callable[[dict[str, Any]], dict[str, Any]]
ArtifactMapper = Callable[[dict[str, Any]], list[dict[str, Any]]]
ContextReducer = Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]]


@dataclass(frozen=True)
class ToolEntry:
    name: str
    description: str
    parameters: dict[str, Any]
    handler: ToolHandler
    category: str
    toolset: str = "default"
    requires_confirmation: bool = False
    destructive: bool = False
    writes_project: bool = False
    preflight: ToolHandler | None = None
    result_schema: dict[str, Any] | None = None
    artifact_mapper: ArtifactMapper | None = None
    context_reducer: ContextReducer | None = None
    idempotency_key_fields: tuple[str, ...] = ()
    idempotency_scope: str = "request"
    resume_policy: str = "return_result"
    execution_affinity: str = "any"
    timeout_seconds: int | None = None
    availability: Callable[[], tuple[bool, str]] | None = None
    source: str = "core"

    def definition(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, ToolEntry] = {}
        self._skill_tools: dict[str, set[str]] = {}
        self._before_execute: Callable[[str, dict[str, Any]], None] | None = None
        self._after_execute: Callable[[str, dict[str, Any], dict[str, Any]], None] | None = None

    def register(self, entry: ToolEntry) -> None:
        existing = self._tools.get(entry.name)
        if existing is not None and existing != entry:
            raise ValueError(
                f"Tool name collision: {entry.name} ({existing.source} vs {entry.source})"
            )
        self._tools[entry.name] = entry

    def set_skill_tools(self, skill_tools: dict[str, list[str]]) -> None:
        self._skill_tools = {
            str(skill_name): {str(tool_name) for tool_name in tool_names}
            for skill_name, tool_names in skill_tools.items()
            if tool_names
        }

    def set_execution_hooks(
        self,
        *,
        before: Callable[[str, dict[str, Any]], None] | None = None,
        after: Callable[[str, dict[str, Any], dict[str, Any]], None] | None = None,
    ) -> None:
        self._before_execute = before
        self._after_execute = after

    def get(self, name: str) -> ToolEntry:
        if name not in self._tools:
            raise KeyError(f"Tool not registered: {name}")
        return self._tools[name]

    def tool_names(self) -> set[str]:
        return set(self._tools)

    def toolsets(self) -> set[str]:
        return {entry.toolset for entry in self._tools.values()}

    def context_reducers(self) -> dict[str, ContextReducer]:
        """Return Plugin/core projections used only for model context compaction."""
        return {
            name: entry.context_reducer
            for name, entry in self._tools.items()
            if entry.context_reducer is not None
        }

    def definitions_for_skill(self, skill_name: str) -> list[dict[str, Any]]:
        return self.definitions_for_skills([skill_name])

    def definitions_for_skills(self, skill_names: list[str]) -> list[dict[str, Any]]:
        """Return the controlled union for all progressively loaded Skills."""
        configured = [self._skill_tools[name] for name in skill_names if name in self._skill_tools]
        if not configured:
            return [entry.definition() for entry in self._tools.values()]
        allowed: set[str] = set().union(*configured)
        return [
            entry.definition()
            for entry in self._tools.values()
            if entry.name in allowed
            or entry.category in {"skill", "planning", "delegation", "learning"}
        ]

    def execute(self, name: str, arguments: dict[str, Any]) -> tuple[dict[str, Any], int]:
        entry = self.get(name)
        started = time.monotonic()
        try:
            if self._before_execute is not None:
                self._before_execute(name, arguments)
            if entry.availability is not None:
                available, reason = entry.availability()
                if not available:
                    raise RuntimeError(reason or f"Tool unavailable: {name}")
            result = entry.handler(arguments)
            if "success" not in result:
                result = {"success": True, **result}
            if result.get("success") and entry.artifact_mapper is not None:
                result = {**result, "artifacts": entry.artifact_mapper(result)}
            result = make_json_safe(result)
        except Exception as exc:
            result = {"success": False, "error": str(exc)}
        if self._after_execute is not None:
            try:
                self._after_execute(name, arguments, result)
            except Exception:
                # Hook failures are diagnostic-only and may never overwrite a
                # completed tool result.
                pass
        duration_ms = int((time.monotonic() - started) * 1000)
        return result, duration_ms

    def idempotency_key(self, name: str, arguments: dict[str, Any]) -> str | None:
        entry = self.get(name)
        if not entry.idempotency_key_fields:
            return None
        import json

        values = {
            field_name: arguments.get(field_name)
            for field_name in entry.idempotency_key_fields
        }
        return json.dumps(
            {"tool": name, "scope": entry.idempotency_scope, "values": values},
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )


def make_json_safe(value: Any) -> Any:
    """Convert QGIS/PyQt values into JSON-serializable Python values."""
    if value is None or isinstance(value, str | int | float | bool):
        return value
    if isinstance(value, date | datetime):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, bytes | bytearray):
        return bytes(value).decode("utf-8", errors="replace")
    if isinstance(value, dict):
        return {str(make_json_safe(key)): make_json_safe(item) for key, item in value.items()}
    if isinstance(value, list | tuple | set):
        return [make_json_safe(item) for item in value]

    converted, handled = _convert_qvariant_like(value)
    if handled:
        return make_json_safe(converted)

    return str(value)


def _convert_qvariant_like(value: Any) -> tuple[Any, bool]:
    type_name = type(value).__name__.lower()
    module_name = type(value).__module__.lower()
    looks_qt_value = "qvariant" in type_name or "pyqt" in module_name or "qgis" in module_name
    if not looks_qt_value:
        return value, False

    for null_method in ("isNull", "isValid"):
        method = getattr(value, null_method, None)
        if callable(method):
            try:
                state = bool(method())
            except Exception:
                continue
            if null_method == "isNull" and state:
                return None, True
            if null_method == "isValid" and not state:
                return None, True

    for method_name in ("toPyObject", "value", "toString"):
        method = getattr(value, method_name, None)
        if not callable(method):
            continue
        try:
            converted = method()
        except Exception:
            continue
        if converted is not value:
            return converted, True
    return str(value), True
