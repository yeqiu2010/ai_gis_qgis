---
name: sam3-remote-segmentation
description: 通过已配置的 SAM3-Geo-API 从 QGIS 遥感栅格中分割建筑、水体、道路、树冠等地物，支持文本提示、自动分割、AOI 范围和选中矢量要素边界框提示，输出地理配准掩码或面图层。适用于影像地物识别、遥感影像分割、按行政区或地块限定分割、候选框精细轮廓，以及先分割后继续裁剪、相交、空间连接、面积统计或制图的任务。
allowed-tools:
  - list_layers
  - inspect_layer
  - inspect_layers
  - check_sam3_service
  - inspect_sam3_segmentation_inputs
  - segment_remote_sensing_image
  - create_plan
  - revise_plan
  - get_task_state
  - update_plan_step
  - complete_plan_step
  - register_artifact
  - finalize_task
  - load_skill
license: MIT
metadata:
  hermes:
    tags: [sam3, remote-sensing, segmentation, raster, vectorization]
    related_skills: [qgis-toolbox, gis-pipeline, generate-land-cover-map]
    requires_tools: [check_sam3_service, inspect_sam3_segmentation_inputs, segment_remote_sensing_image]
  qgis_agent:
    inputs:
      required:
        input_layer_id: {type: qgis_raster_layer}
      optional:
        prompt: {type: string}
        aoi_layer_id: {type: qgis_vector_layer}
        boxes_layer_id: {type: qgis_vector_layer}
    outputs:
      segmentation_outputs: {type: array}
    side_effects:
      uploads_data: true
      modifies_qgis_project: true
      writes_files: true
      requires_confirmation: true
      concurrency: qgis_main_thread_serial
    completion:
      required_artifacts: [segmentation_outputs]
      checks: [output_files_exist, output_layers_loaded]
---

# SAM3 遥感影像分割

通过固定受信任工具完成影像预处理、SAM3 API 调用、掩码校验、矢量化和 QGIS 图层加载。不要生成网络访问代码，不要用 `execute_gis_code` 调用 SAM3。

## 路由模式

- 用户描述目标类别时使用 `mode=text`，把类别规范化为简短英文 prompt，同时保留用户原始语义。
- 用户明确要求自动识别全部可见对象时使用 `mode=automatic`。说明该模式是实验性的通用提示分割。
- 用户指定候选框或选中要素时使用 `mode=boxes`，传入 `boxes_layer_id`；默认只使用选择集。
- 用户指定行政区、地块或样区作为处理范围时使用 `scope_mode=aoi` 和 `aoi_layer_id`。
- 用户说“当前视图/当前地图范围”时使用 `scope_mode=canvas`。
- 其余情况使用 `scope_mode=full`；输入检查提示超限时不得继续全图上传。

## 强制流程

1. 调用 `list_layers`，以真实 layer ID 绑定输入影像和可选矢量图层。
2. 必要时调用 `inspect_layer`/`inspect_layers` 消除同名、图层类型、CRS 或选择范围歧义。
3. 调用 `check_sam3_service`。模型未就绪、服务不可达或鉴权失败时停止。
4. 调用 `inspect_sam3_segmentation_inputs`，传入最终影像、范围、波段和框图层参数。
5. 检查 `inspection_complete`、预计像元数、上传大小、RGB 波段、空间相交和 warnings。`success=false` 时不得执行。
6. 调用 `segment_remote_sensing_image`。该工具需要用户确认，并会明确上传目标服务、写入文件和加载图层。
7. 工具成功后使用 `register_artifact` 登记 `artifact_type=segmentation_outputs`，value 至少包含 `job_id`、`outputs` 和 `loaded_layers`。
8. 只有存在真实输出文件和已加载图层时才报告分割完成。

## 参数规则

- `input_layer_id`、`aoi_layer_id`、`boxes_layer_id` 必须使用工具返回的真实 ID，不使用名称猜测。
- 文本 prompt 优先使用单个英文类别或短语，例如 `building`、`water`、`road`、`tree canopy`、`solar panel`。
- 不确定用户目标类别时先询问，不能静默扩大或改变类别。
- `min_size_pixels`/`max_size_pixels` 的单位是像素数，不是平方米。
- 用户未指定输出时默认 `output_types=["vector"]`；要求保留掩码时使用 `["vector", "raster"]`。
- 多波段影像只有在用户明确指定时传 `rgb_bands`；否则让检查工具选择前三波段或复制灰度波段。
- `output_name` 使用简短类别名，不传路径。文件由工具写入隔离工作目录。
- 不允许向工具传服务 URL、token、Python 代码或外部输出路径。

## 矢量组合流程

用户请求包含分割后的 GIS 操作时，先完成并登记分割产物，再加载后续 Skill：

- 一个明确单步操作，例如裁剪或缓冲：加载 `qgis-toolbox`。
- 多图层、多步骤、统计汇总、字段/CRS 推断或制图：加载 `gis-pipeline`。

后续流程必须使用 `segment_remote_sensing_image.loaded_layers[].id` 作为分割图层输入。不要假设输出图层名称，也不要在分割成功前生成后续代码。

AOI 模式的矢量输出已经按 AOI 精确裁剪。若用户还要求按每个地块统计，后续 Pipeline 再用结果面与原地块做相交、面积汇总和比例计算。

## 完成与失败

- `no_objects_found` 是没有匹配对象，不是成功。建议调整 prompt、置信度或范围。
- `input_limit_exceeded` 时改用 AOI/当前画布，不能绕过像元或框数量门禁。
- 矢量化失败但 raster 输出成功时，明确报告部分成功；只有用户接受掩码时才可继续。
- API 超时后不要自动重复提交，避免服务端仍在推理时创建重复任务。
- 回复中说明实际模式、prompt、对象数、输出图层名、文件路径和 warnings。
